package com.example.ApiProyecto;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ApiProyectoApplicationTests {

	@Test
	void contextLoads() {
	}

}
