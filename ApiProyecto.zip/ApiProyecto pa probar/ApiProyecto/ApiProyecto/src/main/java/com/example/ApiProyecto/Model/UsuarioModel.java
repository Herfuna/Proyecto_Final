package com.example.ApiProyecto.Model;


import com.fasterxml.jackson.annotation.JsonBackReference;

import jakarta.persistence.*;
import lombok.Data;

@Entity
@Data
public class UsuarioModel {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id_persona;

    private String nombre;
    private String apellido;
    private String telefono;
    private String correo;
    
   
    @ManyToOne
    @JoinColumn(name = "id_evento") // Este será el ID del evento al que pertenece el usuario
    @JsonBackReference // Evita la serialización cíclica
    private EventoModel eventoModel;
}
