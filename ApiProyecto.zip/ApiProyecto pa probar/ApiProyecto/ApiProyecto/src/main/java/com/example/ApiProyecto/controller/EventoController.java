
package com.example.ApiProyecto.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.web.bind.annotation.*;

import com.example.ApiProyecto.Model.EventoModel;
import com.example.ApiProyecto.Model.UsuarioModel;
import com.example.ApiProyecto.service.EventoService;

import jakarta.persistence.EntityNotFoundException;

@RestController
@RequestMapping("/eventos")
public class EventoController {
    @Autowired
    private EventoService eventoService;
    
   
   


    //get
    @GetMapping
    public List<EventoModel> listarTodo(){
        return eventoService.getalleEventoModels();
    }
    @GetMapping("/{id}/usuarios")
public List<UsuarioModel> obtenerUsuariosPorEvento(@PathVariable Long id) {
    EventoModel evento = eventoService.findById(id)
        .orElseThrow(() -> new EntityNotFoundException("Evento no encontrado"));
    return evento.getUsuarioModel();
}
    //post
    @PostMapping
    public EventoModel crear(@RequestBody EventoModel eventoModel){
        return eventoService.creatEventoModel(eventoModel);
    }

    //put
    @PostMapping("editar/{id}")
    public EventoModel actualizar(@RequestBody EventoModel eventoModel, @PathVariable Long id){
        eventoModel.setId_evento(id);
        return eventoService.updateEventoModel(eventoModel);
    }

    //delete
    @DeleteMapping("eliminar/{id}")
    public void eliminar(@PathVariable Long id){
        eventoService.deleteEventoById(id);
    }
  
  
    

}
