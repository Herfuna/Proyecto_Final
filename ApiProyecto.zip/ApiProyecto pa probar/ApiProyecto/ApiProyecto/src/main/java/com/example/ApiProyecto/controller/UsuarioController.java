package com.example.ApiProyecto.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;


import com.example.ApiProyecto.Model.UsuarioModel;
import com.example.ApiProyecto.service.UsuarioService;

@RestController
@RequestMapping("/usuario")
public class UsuarioController {
    @Autowired
    UsuarioService usuarioService;

    //get
    @GetMapping()
    public List<UsuarioModel> listarTodo(){
        return usuarioService.getallUsuarios();
    }

    
    //post
    @PostMapping()
    public UsuarioModel crear(@RequestBody UsuarioModel usuarioModel){
        return usuarioService.creatUsuarioModel(usuarioModel);
    }

    //put
    @PostMapping("/editar/{id}")
    public UsuarioModel actualizar(@RequestBody UsuarioModel usuarioModel, @PathVariable Long id){
        usuarioModel.setId_persona(id);
        return usuarioService.updateUsuarioModel(usuarioModel);
    }

    //delete
    @DeleteMapping("eliminar/{id}")
    public void eliminar(@PathVariable Long id){
        usuarioService.deleteUsuarioById(id);
    }


}
