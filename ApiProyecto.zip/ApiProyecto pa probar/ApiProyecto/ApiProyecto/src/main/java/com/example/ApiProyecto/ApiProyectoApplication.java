package com.example.ApiProyecto;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ApiProyectoApplication {

	public static void main(String[] args) {
		SpringApplication.run(ApiProyectoApplication.class, args);
	}

}
