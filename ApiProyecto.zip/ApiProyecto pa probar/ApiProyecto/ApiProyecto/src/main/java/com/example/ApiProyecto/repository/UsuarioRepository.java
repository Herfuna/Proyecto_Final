package com.example.ApiProyecto.repository;



import org.springframework.data.jpa.repository.JpaRepository;

import com.example.ApiProyecto.Model.UsuarioModel;

public interface UsuarioRepository extends JpaRepository<UsuarioModel, Long>{
    
}
