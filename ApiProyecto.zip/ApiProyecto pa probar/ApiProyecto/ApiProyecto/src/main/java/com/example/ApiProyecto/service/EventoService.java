package com.example.ApiProyecto.service;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.ApiProyecto.Model.EventoModel;
import com.example.ApiProyecto.repository.EventoRepository;



@Service
public class EventoService {
    @Autowired
     private EventoRepository eventoRepository;
    
    //Mostrar
    public List<EventoModel> getalleEventoModels(){
        return eventoRepository.findAll();
    }

    //crear evento
    public EventoModel creatEventoModel(EventoModel eventoModel){
        return eventoRepository.save(eventoModel);
    }

    //Editar
    public EventoModel updateEventoModel(EventoModel eventoModel){
        return eventoRepository.save(eventoModel);
    }
    //eliminar
    public void deleteEventoById(Long id){
        eventoRepository.deleteById(id);
    }

    public Optional<EventoModel> findById(Long id) {
        return eventoRepository.findById(id);
    }
  
}
