package com.example.ApiProyecto.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.ApiProyecto.Model.UsuarioModel;
import com.example.ApiProyecto.repository.UsuarioRepository;

@Service
public class UsuarioService {
    @Autowired
   private UsuarioRepository usuarioRepository;
    

    //Mostrar
    public List<UsuarioModel> getallUsuarios(){
        return usuarioRepository.findAll();
    }

    //crear user
    public UsuarioModel creatUsuarioModel(UsuarioModel usuarioModel){
        return usuarioRepository.save(usuarioModel);
    }

    //Editar
    public UsuarioModel updateUsuarioModel(UsuarioModel usuarioModel){
        return usuarioRepository.save(usuarioModel);
    }
    //eliminar
    public void deleteUsuarioById(Long id){
        usuarioRepository.deleteById(id);
    }

    

}
