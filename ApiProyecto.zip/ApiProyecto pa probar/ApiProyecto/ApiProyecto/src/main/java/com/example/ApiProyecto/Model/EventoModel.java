package com.example.ApiProyecto.Model;

import java.util.ArrayList;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonManagedReference;

import jakarta.persistence.*;
import lombok.Data;

@Entity
@Data
public class EventoModel {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id_evento;

    private String nombreEvento;
    private String fecha;
    private String hora;
    private String Lugar;
    
    // Mapeo de usuarios asociados a este evento, sin orphanRemoval
    @OneToMany(mappedBy = "eventoModel", cascade = CascadeType.ALL, fetch = FetchType.LAZY)
    @JsonManagedReference // Evita la serialización cíclica
    private List<UsuarioModel> usuarioModel = new ArrayList<>();

}
