package com.example.ApiProyecto.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.ApiProyecto.Model.EventoModel;

public interface EventoRepository extends JpaRepository<EventoModel, Long> {
    
}
